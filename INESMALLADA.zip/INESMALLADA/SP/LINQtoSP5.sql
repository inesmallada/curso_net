--Procedimiento para cargar la grid en el formulario

Create procedure SP_CargarGrid
As
Select *
from PRODUCTOS


